"""Module cli contains functions for greeting user."""
