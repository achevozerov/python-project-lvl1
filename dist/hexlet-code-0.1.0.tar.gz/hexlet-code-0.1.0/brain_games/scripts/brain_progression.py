"""Contains main function that starts the progression game."""

from random import randint

import prompt
from brain_games import cli


def generate_sequence(name, right_answer_count=0):
    """
    Generate question and check his right.

    Parameters:
        name (str): user name
        right_answer_count (int): integer number meaning right answer count
    """
    sequence_length = randint(5, 10)
    start = randint(2, 30)
    step = randint(1, 6)
    hidden_num = rand.int(1, sequence_length)
    seq_list = []
    for i in range(sequence_length):
        seq_list.append(start)
        start += step
    return seq_list


def main():
    """Launch the progression game."""
    name = cli.welcome_user()
    print('What number is missing in the progression?')
    print(generate_sequence(name))


if __name__ == '__main__':
    main()
