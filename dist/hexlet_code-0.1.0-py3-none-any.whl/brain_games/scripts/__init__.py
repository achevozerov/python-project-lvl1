"""Module brain_games contains func main who activate and manage game."""
